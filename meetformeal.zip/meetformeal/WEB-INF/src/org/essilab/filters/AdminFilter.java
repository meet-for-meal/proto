package org.essilab.filters;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminFilter {
    public static final String CONNECTION     = "/connect-admin";
    public static final String ATT_SESSION_USER = "sessionUser.is_admin";
 
    public void init( FilterConfig config ) throws ServletException {
    }
 
    public void doFilter( ServletRequest req, ServletResponse res, FilterChain chain ) throws IOException,
            ServletException {
        /* Cast request and response */
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
 
        /* R�cup�ration de la session depuis la requ�te */
        HttpSession session = request.getSession();
 
        /**
         * If sessionUser is null, then there is no valid session
         */
        System.out.println(session.getAttribute( ATT_SESSION_USER ));
        if ( session.getAttribute( ATT_SESSION_USER ) != String.valueOf(1) ) {
            /* Redirection vers la page publique */
            response.sendRedirect( request.getContextPath() +  CONNECTION);
        } else {
            /* Affichage de la page restreinte */
            chain.doFilter( request, response );
        }
    }
 
    public void destroy() {
    }
}
